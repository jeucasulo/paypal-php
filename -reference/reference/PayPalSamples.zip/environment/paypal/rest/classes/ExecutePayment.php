<?php

require_once 'Oauth.php';
require_once 'CurlCommand.php';

$Execute = new ExecutePayment();
echo $Execute->ExecutePay();

class ExecutePayment{
    public function ExecutePay(){
        $bearer = new Oauth();
        $callAPI = new CurlCommand();
        $method = "ExecutePayment";
        $PaymentID = $_POST['paymentID'];
        $PayerID = $_POST['payerID'];
        $url = "https://api.sandbox.paypal.com/v1/payments/payment/".$PaymentID."/execute";
        $headers = array("Content-Type: application/json", "Authorization: ".$bearer->getToken());
        $fields = json_encode(array("payer_id"=> "".$PayerID));

        $response = $callAPI->RunCurl($url, $headers, $fields, $method);
        return json_encode($response);
    }
}