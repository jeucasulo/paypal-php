<?php

require_once 'Oauth.php';
require_once 'CurlCommand.php';

class GetSaleInfo{
    public function getInfo(){
        $callAPI = new CurlCommand();
        $bearer = new Oauth();
        $url = "https://api.sandbox.paypal.com/v1/payments/payment?count=1&start_index=0";
        $headers = array("Content-Type: application/json", "Authorization: ".$bearer->getToken());
        
        $response = $callAPI->getDetails($url, $headers);

        return $response;
    }
}