<?php

class Config{

    private $client = "AQmWM_kGFCQLgKNzpfWAk06U1CqSlxGYIQzGKhIG6WcwSgkWw7dOgMVxdfxJceFcKuAsOk3vZ51d1WS8";
    private $secret = "EPisxlsGoZNxfrnH9D8pluodJF8xAHvkXWm8HtpgVYRlAodJxPn3y9IJ7PXJS4kgL-5AdZY09smIWPP8";

    public function getClient(){
        return $this->client;
    }
    public function getSecret(){
        return $this->secret;
    }
}