<?php

require ("../../layouts/layout.php");

?>
</br>

<center><h3>Welcome to PayPal Checkout</h3></center>
</br>


<center><a href="http://<?php echo $_SERVER['HTTP_HOST']?>/paypal/rest/paypalcheckout/clientside.php"><h1>Express Checkout jsv4 - Client Side</h1></center>
</br>

<center><a href="http://<?php echo $_SERVER['HTTP_HOST']?>/paypal/rest/paypalcheckout/serverside.php"><h1>Express Checkout jsv4 - Server Side</h1></center>

