var hostName = window.location.origin;
var pathCreate ="/paypal/rest/classes/CreatePayment.php";
var pathExecute ="/paypal/rest/classes/ExecutePayment.php";
var pathGetSaleInfo ="/paypal/rest/classes/GetSaleInfo.php";

var CreatePaymentPath = hostName+pathCreate;
var ExecutePaymentPath = hostName+pathExecute;
var GetSaleInfoPath = hostName+pathGetSaleInfo;
paypal.Button.render({
    env: 'sandbox', // Or 'production'

    style: {
      label: 'paypal',
      size:  'medium',    // small | medium | large | responsive
      shape: 'rect',     // pill | rect
      color: 'black',     // gold | blue | silver | black
      tagline: false    
  },
    // Set up the payment:
    // 1. Add a payment callback
    payment: function(data, actions) {
      // 2. Make a request to your server
      return actions.request.post(CreatePaymentPath)
        .then(function(res) {
          // 3. Return res.id from the response
          return res.id;
        });
    },
    // Execute the payment:
    // 1. Add an onAuthorize callback
    onAuthorize: function(data, actions) {
      // 2. Make a request to your server
      return actions.request.post(ExecutePaymentPath, {
        paymentID: data.paymentID,
        payerID:   data.payerID
      })
        .then(function(res) {
          // 3. Show the buyer a confirmation message.
          var resobj = JSON.parse(res);
          var saleID = resobj.transactions['0'].related_resources['0'].sale['id']; 
          var state = resobj.transactions['0'].related_resources['0'].sale['state'];
          if(state == 'completed'){
            console.log(resobj);
            console.log(saleID);
            alert("Payment Completed!");
            window.location = "../../success.php";
          }else{
            alert("Your payment cannot be completed");
          }
        });
    }
  }, '#paypal-button');

