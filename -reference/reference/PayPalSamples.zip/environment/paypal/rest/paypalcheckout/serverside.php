<?php

require ("../../layouts/layout.php");

?>
<br/>

<center><h3>Server Side Button</h3></center>
<body>
<br/>
<br/>
<br/>
<script src="https://www.paypalobjects.com/api/checkout.js"></script>


<center><div id="paypal-button"></div></center>
<script src="http://<?php echo $_SERVER['HTTP_HOST']?>/paypal/rest/paypalcheckout/serverside.js"></script>

</body>
