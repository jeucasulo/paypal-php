<?php

require ("layouts/layout.php");

?>
</br>

<center><h3><a href="http://<?php echo $_SERVER['HTTP_HOST']?>/paypal/rest/paypalcheckout/index.php">PayPal Express</h3></center>
