<?php

require ("layouts/layout.php");
require ("rest/classes/GetSaleInfo.php");

?>
</br>

<center><h1>Success!</h1></center>
<br/>
<br/>
<br/>

<center><h3>Your Transaction ID is</h3></center>
<br/>
<center><pre><h4>
<?php
    $getInfo = new GetSaleInfo();
   $saleID = json_decode($getInfo->getInfo(), true);
   echo $saleID["payments"]["0"]["transactions"]["0"]["related_resources"]["0"]["sale"]["id"];
?>
</h4></pre></center>
