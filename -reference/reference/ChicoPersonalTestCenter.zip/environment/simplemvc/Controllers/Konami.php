<?php

require './config.php';
include './Classes/RunCurl.php';
include './Classes/Session.php';

class Konami extends Controller{
	
	public function BillAgree($data){

		$reqs = array(
		'USER' => $data['user'],
	  	'PWD' => $data['pwd'],
	  	'SIGNATURE' => $data['sign'],

	 	'VERSION' => $data['ver'],
	    'METHOD'=> 'SetExpressCheckout',
	 
	    'PAYMENTREQUEST_0_AMT' => '0',
	    'PAYMENTREQUEST_0_CURRENCYCODE' => 'BRL',
	    'PAYMENTREQUEST_0_ITEMAMT' => '0',
	 
	    'CANCELURL' => 'http://www.pudim.com.br/',
	    'BUTTONSOURCE' => 'BR_EC_EMPRESA');

	    if(isset($_POST['billing'])) {
	    
			$bill = array(
			'PAYMENTREQUEST_0_PAYMENTACTION' => 'AUTHORIZATION',
			'L_BILLINGTYPE0' => 'MerchantInitiatedBilling',
			'L_BILLINGAGREEMENTDESCRIPTION0' => 'Exemplo',
			'RETURNURL' => 'http://'.$data['localhost'].'/simplemvc/createba',);

			$reqs += $bill;

			$_SESSION['billing'] = 'true';

	    } else {

		    $bill = array(
		    'PAYMENTREQUEST_0_PAYMENTACTION' => 'SALE',
			'RETURNURL' => 'http://'.$data['localhost'].'/simplemvc/doec',);

		    $reqs += $bill;
	    }

	    //Instancia RunCurl
		$curl = new RunCurl(); 
		//Coleta resultado do return de Run em RunCurl
		$decode = $curl->Run($reqs, $data['endpoint']); 

		// Distribui o valor em uma array (resNVP) para pegar o token
		if (preg_match_all('/(?<name>[^\=]+)\=(?<value>[^&]+)&?/', $decode, $matches)) {
        foreach ($matches['name'] as $offset => $name) {
            $_SESSION[$name] = $matches['value'][$offset];
        	}
   		}

		SessionRetrieve::getSession($_POST);

    	$token = $_SESSION['TOKEN']; //Recebe o valor de TOKEN da array para uma variável

    	//echo $token; //Printa token em tela

    	if (isset($_SESSION['ACK']) && $_SESSION['ACK'] == 'Success') {				// Verifica se o SetEC foi executado com sucesso
	    	$query = array(
	        	'cmd'    => '_express-checkout',								// Cria uma query string com cmd como express-checkout
	       		'token'  => $token 												// Adiciona o token como $token
    		);

    		$redirect = sprintf('%s?%s', $data['url'], http_build_query($query));

    		$_SESSION['redirect'] = $redirect;

    	}

		// echo '<pre>';
		// print_r($reqs);
		// echo '</pre>';
		//echo $_SESSION['billing'];
		echo '<pre>';
		print_r($decode);
		echo '</pre>';

		return $decode;
	}

/*	public function Refund($data){

		$reqs = array(
		'USER' => $data['user'],
	  	'PWD' => $data['pwd'],
	  	'SIGNATURE' => $data['sign'],

	 	'VERSION' => $data['ver'],
	    'METHOD'=> 'RefundTransaction',

	    'CURRENCYCODE' => $data['curr'],
	    'TRANSACTIONID' => $_POST['transaction_id'],
		'REFUNDTYPE' => $_POST['reftype']);

		if($_POST['reftype'] == "Partial") {
		
		$amount = array(
		'AMT' => str_replace(",", ".", 
				 	str_replace(".", "", 
				 		$_POST["rpamount"])
				 )
		);

		$reqs += $amount;

		}

    	$curl = new RunCurl(); //Instancia RunCurl
		$decode = $curl->Run($reqs, $data['endpoint']); //Coleta resultado do return de Run em RunCurl

		echo '<pre>';
		print_r($decode);
		echo '</pre>';

		return $decode;
	}*/
}

	$k_code = new Konami();

	if(isset($_REQUEST['sub1'])) {

		$k_code->BillAgree($data); //Create a Billing Account
	}

	if(isset($_REQUEST['sub2'])) {

		$k_code->Refund($data); //Refund amount back to the user
	}

?>