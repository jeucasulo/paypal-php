<?php

require './config.php';
include './Classes/RunCurl.php';
include './Classes/Session.php';

class Kill extends Controller{

}

	if(isset($_REQUEST['submit'])) {

		Session::KillEmAll();
		
	}

?>
