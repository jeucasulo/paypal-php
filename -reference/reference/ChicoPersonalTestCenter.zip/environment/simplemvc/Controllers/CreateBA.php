<?php

require './config.php';
include './Classes/RunCurl.php';
include './Classes/Session.php';

class CreateBA extends Controller
{

  public function Create($data)
  {

    $reqs = array(
      'METHOD' => 'CreateBillingAgreement',
      'TOKEN' => $_POST['TOKEN'],
    );

  $curl = new RunCurl(); //Instancia RunCurl
	$query = $curl->Run($reqs, $data); //Coleta resultado do return de Run em RunCurl

  Session::GetQuery($query);

  echo '<pre>';
  print_r($query);
  echo '</pre>';

  return $query;

  }

}

$res = new CreateBA();

if(isset($_REQUEST['submit']))
{
  $res->Create($data);
}
?>
