<?php

require './config.php';
include './Classes/RunCurl.php';
include './Classes/Session.php';

class Refund extends Controller
{
    public function MyMoney($data)
    {

		$reqs = array(
	    'METHOD'=> 'RefundTransaction',
	    'CURRENCYCODE' => $data['curr'],
	    'TRANSACTIONID' => $_POST['transaction_id'],
		'REFUNDTYPE' => $_POST['reftype']);

		if($_POST['reftype'] == "Partial") {
		
		$amount = array(
		'AMT' => str_replace(",", ".", 
				 	str_replace(".", "", 
				 		$_POST["rpamount"])
				 )
		);

		$reqs += $amount;

		}

    	$curl = new RunCurl(); //Instancia RunCurl
		$decode = $curl->Run($reqs, $data); //Coleta resultado do return de Run em RunCurl

		echo '<pre>';
		print_r($decode);
		echo '</pre>';

		return $decode;
	}
}

	$refund = new Refund();

	if(isset($_REQUEST['submit'])) {
		$refund->MyMoney($data);
	}

?>
