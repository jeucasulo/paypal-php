<?php

require './config.php';
include './Classes/RunCurl.php';
include './Classes/Session.php';

if(!isset($_SESSION['TOKEN'])) { 
		$_SESSION['TOKEN'] = $_GET['token'];
	}

class DoEC extends Controller
{
	public function GetECAction($data)
	{
		$reqs = array(
			'METHOD' => 'GetExpressCheckoutDetails',
			'TOKEN' => $_SESSION['TOKEN']);

		$curl = new RunCurl();
		$decode = $curl->Run($reqs, $data);
		
		if (preg_match_all('/(?<name>[^\=]+)\=(?<value>[^&]+)&?/', $decode, $matches)) 
		{
        	foreach ($matches['name'] as $offset => $name) 
        	{
        		$_SESSION[$name] = $matches['value'][$offset];
			}
   		}
		
   		//echo '<pre>'; print_r($_SESSION); echo '</pre>';
   		//echo '<pre>'; print_r($decode); echo '</pre>';
		
		return $decode;
		
	}
	
	public function DoECAction($data, $payerid)
	{
		
		$_SESSION['PayerID'] = $payerid; // Colocar isset
		
		$reqs = array(
    	'METHOD'=> 'DoExpressCheckoutPayment',

		'TOKEN' => $_SESSION['TOKEN'],
		'PAYERID' => $_SESSION['PAYERID'],

		'PAYMENTREQUEST_0_PAYMENTACTION' => 'SALE',
		'PAYMENTREQUEST_0_AMT' => $_POST['confAMT'], //Recebe valor total
		'PAYMENTREQUEST_0_CURRENCYCODE' => $_SESSION['PAYMENTREQUEST_0_CURRENCYCODE'], //Recebe currency
		'PAYMENTREQUEST_0_ITEMAMT' => $_SESSION['PAYMENTREQUEST_0_ITEMAMT'], //Recebe valor do item
		'PAYMENTREQUEST_0_DESC' => $_SESSION['PAYMENTREQUEST_0_DESC'],
		
		'L_PAYMENTREQUEST_0_NAME0' => $_SESSION['L_PAYMENTREQUEST_0_NAME0'],
		'L_PAYMENTREQUEST_0_DESC0' => $_SESSION['L_PAYMENTREQUEST_0_DESC0'],
		'L_PAYMENTREQUEST_0_AMT0' => $_SESSION['L_PAYMENTREQUEST_0_AMT0'],
		'L_PAYMENTREQUEST_0_QTY0' => $_SESSION['L_PAYMENTREQUEST_0_QTY0'],
	
		'L_PAYMENTREQUEST_0_NAME1' => $_SESSION['L_PAYMENTREQUEST_0_NAME1'],
		'L_PAYMENTREQUEST_0_DESC1' => $_SESSION['L_PAYMENTREQUEST_0_DESC1'],
		'L_PAYMENTREQUEST_0_AMT1' => $_SESSION['L_PAYMENTREQUEST_0_AMT1'],
		
		'PAYMENTREQUEST_0_INVNUM' => $_SESSION['PAYMENTREQUEST_0_INVNUM'],
		
		'L_PAYMENTREQUEST_0_QTY1' => $_SESSION['L_PAYMENTREQUEST_0_QTY1']);


		if(isset($_SESSION['merchantSubject'])){
				$subject = array('SUBJECT' => 'ciscoproo0-facilitator@gmail.com');
				$reqs += $subject;
				unset($_SESSION['SUBJECT']);
		}

		if(isset($_POST['addressShipping'])){
			$shipping = array(
				'ADDROVERRIDE' => '1',
				'PAYMENTREQUEST_0_SHIPTOSTREET' => $_SESSION['PAYMENTREQUEST_0_SHIPTOSTREET'],
				'PAYMENTREQUEST_0_SHIPTOSTREET2' => $_SESSION['PAYMENTREQUEST_0_SHIPTOSTREET2'],
				'PAYMENTREQUEST_0_SHIPTOCITY' => $_SESSION['PAYMENTREQUEST_0_SHIPTOCITY'],
				'PAYMENTREQUEST_0_SHIPTOSTATE' => $_SESSION['PAYMENTREQUEST_0_SHIPTOSTATE'],
				'PAYMENTREQUEST_0_SHIPTOCOUNTRYCODE' => 'PAYMENTREQUEST_0_SHIPTOCOUNTRYCODE',
				'PAYMENTREQUEST_0_SHIPTOZIP' => $_SESSION['PAYMENTREQUEST_0_SHIPTOZIP'],
				'PAYMENTREQUEST_0_SHIPTOPHONENUM' => $_SESSION['PAYMENTREQUEST_0_SHIPTOPHONENUM']);
			$reqs += $shipping;
		}
		if (!isset($_POST['addressShipping'])){
			$shipping = array('NOSHIPPING' => '1');
			
			$reqs += $shipping;
		}

		$curl = new RunCurl(); //Instancia RunCurl
		$decode = $curl->Run($reqs, $data); //Coleta resultado do return de Run em RunCurl

		if (preg_match_all('/(?<name>[^\=]+)\=(?<value>[^&]+)&?/', $decode, $matches)) {
        foreach ($matches['name'] as $offset => $name) {
            $_SESSION[$name] = $matches['value'][$offset];
        	}
   		}

   		echo '<pre>'; print_r($_SESSION); echo '</pre>';
   		echo '<pre>'; print_r($decode); echo '</pre>';

		return $decode;

	}
		public function invoice($limit){
			return substr(base_convert(sha1(uniqid(mt_rand())), 16, 36), 0, $limit);
		}

}


	$res = new DoEC();
	$res->GetECAction($data);


	if(isset($_REQUEST['submit']))
	{
		$res->DoECAction($data, $_GET['PayerID']);
	}

?>
