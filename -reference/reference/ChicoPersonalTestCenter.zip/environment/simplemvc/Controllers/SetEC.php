<?php

include './config.php';
include './Classes/RunCurl.php';
include './Classes/Session.php';

class SetEC extends Controller{

	public function SetECAction($data){

		$reqs = array(
		'PAYMENTREQUEST_0_CURRENCYCODE' => $data['curr'],
	    'METHOD'=> 'SetExpressCheckout',
	    'CANCELURL' => 'http://'.$data['localhost'].'/simplemvc/cancel',
	    'BUTTONSOURCE' => 'BR_EC_EMPRESA',
	    'PAYMENTREQUEST_0_INVNUM' => $this->invoice(12));

	    if(isset($_POST['billing'])) {

				$bill = array(
				'PAYMENTREQUEST_0_DESC' => $_POST['FixedDescription'],
				'PAYMENTREQUEST_0_PAYMENTACTION' => 'SALE',

				'L_BILLINGTYPE0' => 'MerchantInitiatedBilling',
				'L_BILLINGAGREEMENTDESCRIPTION0' => $_POST['FixedDescription']);

				if(isset($_POST['withEC'])) {

				$routes = array(
					'PAYMENTREQUEST_0_AMT' => $_POST['AMT'],
					'PAYMENTREQUEST_0_ITEMAMT' => $_POST['ITEMAMT'],
					'RETURNURL' => 'http://'.$data['localhost'].'/simplemvc/doec');

				$bill += $routes;

				} else {

				$routes = array(
					'PAYMENTREQUEST_0_AMT' => '0.00',
					'PAYMENTREQUEST_0_ITEMAMT' => '0.00',

					'RETURNURL' => 'http://'.$data['localhost'].'/simplemvc/createba');

				$bill += $routes;

				}

				$reqs += $bill;

				$_SESSION['billing'] = 'true';

	    } else {

		    $bill = array(

		    'PAYMENTREQUEST_0_DESC' => $_POST['FixedDescription'],
		    'PAYMENTREQUEST_0_AMT' => $_POST['AMT'],
	    	'PAYMENTREQUEST_0_CURRENCYCODE' => $data['curr'],
		    'PAYMENTREQUEST_0_PAYMENTACTION' => 'SALE',

			'L_PAYMENTREQUEST_0_NAME0' => $_POST['NAME0'],
			'L_PAYMENTREQUEST_0_DESC0' => $_POST['DESC0'],
			'L_PAYMENTREQUEST_0_AMT0' => $_POST['ITEMAMTn0'],
			'L_PAYMENTREQUEST_0_QTY0' => $_POST['QTY0'],
			
			'L_PAYMENTREQUEST_0_NAME1' => $_POST['NAME1'],
			'L_PAYMENTREQUEST_0_DESC1' => $_POST['DESC1'],
			'L_PAYMENTREQUEST_0_AMT1' => $_POST['ITEMAMTn1'],
			'L_PAYMENTREQUEST_0_QTY1' => $_POST['QTY1'],
			

			'RETURNURL' => 'http://'.$data['localhost'].'/simplemvc/doec');

			if(isset($_POST['addressShipping'])){
				$shipping = array(
				'ADDROVERRIDE' => '1',
				'PAYMENTREQUEST_0_SHIPTOSTREET' => $_POST['STREET1'],
				'PAYMENTREQUEST_0_SHIPTOSTREET2' => $_POST['STREET2'],
				'PAYMENTREQUEST_0_SHIPTOCITY' => $_POST['CITY'],
				'PAYMENTREQUEST_0_SHIPTOSTATE' => $_POST['STATE'],
				'PAYMENTREQUEST_0_SHIPTOCOUNTRYCODE' => 'BR',
				'PAYMENTREQUEST_0_SHIPTOZIP' => $_POST['ZIP'],
				'PAYMENTREQUEST_0_SHIPTOPHONENUM' => $_POST['PHONE']);
				$reqs += $shipping;
				$reqs += $bill;
			}
			if (!isset($_POST['addressShipping'])){
				$shipping = array('NOSHIPPING' => '1');
				
				$reqs += $shipping;
				$reqs += $bill;
			}

			}


	$curl = new RunCurl(); //Instancia RunCurl
	$query = $curl->Run($reqs, $data); //Coleta resultado do return de Run em RunCurl

		Session::GetQuery($query); // Joga os valores de query na variavel SESSION

		Session::GetPost($_POST); // Joga os valores POST na variavel SESSION

    $_SESSION['redirect'] = Session::GetURL($data, $_SESSION);

    $token = $_SESSION['TOKEN'];
    	//Recebe o valor de TOKEN da array para uma variável

	if(isset($_REQUEST['submit'])) {
		echo '<pre>';
		print_r($query);
		echo '</pre>';
		return $token;
	} else {
		echo json_encode($query);
	}
    	
	}
			public function invoice($limit){
			return substr(base_convert(sha1(uniqid(mt_rand())), 16, 36), 0, $limit);
		}

}

	$res = new SetEC();

	if(isset($_REQUEST['submit'])) {

		$res->SetECAction($data);
		//Executa a chamada de cURL com os headers para SetExpressCheckout
		echo '<pre>';
		print_r($data);
		echo '</pre>';

	} elseif(isset($_REQUEST['jsv4'])) {
		$res->SetECAction($data);
		//Executa a chamada de cURL com os headers para SetExpressCheckout
		echo '<pre>';
		echo json_encode($data);
		echo '</pre>';
	}

?>
