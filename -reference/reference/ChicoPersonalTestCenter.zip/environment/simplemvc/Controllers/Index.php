<?php

class Index extends Controller {
	
}

?>