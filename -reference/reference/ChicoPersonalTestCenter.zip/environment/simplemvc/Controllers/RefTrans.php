<?php

require './config.php';
include './Classes/RunCurl.php';
include './Classes/Session.php';

class RefTrans extends Controller
{

  public function Transaction($data) {

  	$reqs = array(
    'CURRENCYCODE' => $data['curr'],
    'PAYMENTACTION' => 'SALE',
    'AMT' => $_POST['rtamount'],
    'METHOD' => 'DoReferenceTransaction',
    'REFERENCEID' => $_POST['ba_id'],
    'PAYMENTREQUEST_0_INVNUM' => $_SESSION['PAYMENTREQUEST_0_INVNUM'],
    );

    if(isset($_POST['upinfo'])) {

        $info = array(
            'BILLINGAGREEMENTDESCRIPTION' => $_POST['badesc']
        );

        $reqs += $info;
    }

    $curl = new RunCurl(); //Instancia RunCurl
    $query = $curl->Run($reqs, $data); //Coleta resultado do return de Run em RunCurl

    Session::GetQuery($query);
    
    echo '<pre>';
    print_r($query);
    echo '</pre>';

	return $query;

  }

  public function Cancel($data) {

    $reqs = array(
        'METHOD' => 'BillAgreementUpdate',
        'REFERENCEID' => $_POST['ba_id'],
        'BILLINGAGREEMENTSTATUS' => 'Canceled',
    );

    if(isset($_POST['upinfo'])) {

        $info = array(
            'BILLINGAGREEMENTDESCRIPTION' => $_POST['badesc']
        );

        $reqs += $info;
    }

    $curl = new RunCurl();
    $query = $curl->Run($reqs, $data);

    Session::GetQuery($query);

    echo '<pre>';
    print_r($query);
    echo '</pre>';

    return $query;

  }
  	public function invoice($limit)
  	{
        return substr(base_convert(sha1(uniqid(mt_rand())), 16, 36), 0, $limit);
    }
}


    $res = new RefTrans();
    
    if(isset($_REQUEST['submit']))
    {
    	$res->Transaction($data);
    }
    
    if(isset($_REQUEST['cancel']))
    {
        $res->Cancel($data);
    }

?>
