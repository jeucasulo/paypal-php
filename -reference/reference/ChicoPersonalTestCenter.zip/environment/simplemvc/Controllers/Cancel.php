<?php

class Cancel extends Controller {

}
