<?php 

class Route 
{

	public static $validRoutes = array();

	public static function set($route, $function)
	{
		
		$replacng = str_replace(".","/",$_SERVER["PHP_SELF"]);
		$explodng = explode("/", $replacng);
		
		//echo '<pre>' . print_r($GLOBALS, true ) . '</pre>';

		self::$validRoutes[] = $route;
		
		if(!isset($explodng[4])) {
			$url = $explodng[2];
		} else {
			$url = $explodng[4];
		}

		if ($url == $route)
		{
			$function->__invoke();
		} 
	}
}

?>