 <?php

  header('Content-Type: application/json');

  require 'curl_token_call.php';

   $url = 'https://api.sandbox.paypal.com/v1/payments/payment';

   $keepToken = $printToken['access_token'];

   $headers = array(
   		"Content-Type: application/json",
   		"Authorization: Bearer ".$keepToken.""
   	);

   	$postfields = '{
		  "intent": "sale",
		  "redirect_urls": {
		    "return_url": "http://localhost/paypal/ppplus/curl_finish_call.php",
		    "cancel_url": "https://example.com/your_cancel_url.html"
		  },
		  "payer": {
		    "payment_method": "paypal"
		  },
		  "transactions": [{
		    "amount": {
		      "total": "19.90",
		      "currency": "BRL"
		    }
		  }]
	}';

	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_VERBOSE, true);

    $resPayment = curl_exec($ch);

    $printPay = json_decode($resPayment, true);

	if(curl_errno($ch))
	{
	    echo 'Curl error: ' . curl_error($ch);
	}
	else {

		print_r($resPayment); // -- Check which link is returning

	}

	curl_close($ch);

 ?>
