 <?php

	//header('Content-Type: application/json');

	ob_start();
   	require_once 'curl_payment_call.php';
   	ob_end_clean();

   $keepToken = $printToken['access_token'];
   $payerid = $_POST['payerID']; //Pega resposta da JSON e lança na variavel payerid
   $payid = $_POST['paymentID']; //Pega resposta da JSON e lança na variavel payid

   //$urlpay = $printPay['links']['2']['href'];

   $url = 'https://api.sandbox.paypal.com/v1/payments/payment/'.$payid.'/execute/';

   $headers = array(
   		"Content-Type: application/json",
   		"Authorization: Bearer ".$keepToken.""
   	);
   	
   	$postfields = '{ "payer_id" : "'.$payerid.'" }'; 

	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_VERBOSE, true);

    $resFinish = curl_exec($ch);

    $printFinish = json_decode($resFinish, true);

	if(curl_errno($ch))
	{
	    echo 'Curl error: ' . curl_error($ch);
	}
	else {
		print_r($resFinish);
		//echo $resFinish;
	}

	curl_close($ch); 

 ?>