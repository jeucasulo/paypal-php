 <?php

   //header('Content-Type: application/json');

   $client = "AYUKg1zBJgEbFNBlz1I-_w7ifGRVthypVh3lYARB866GJhhhEALMfN-bZeu3sCMqRy8GWUOPlcPe1wdr";
   $secret = "EAf7wMgJllAdNs96l9FurrlgGyHKP2inUGNeCLpmJcQRk0HlZIOjpWtnLTsKSvn5KCdfQ1AEFAnqkdWo";

   $url = 'https://api.sandbox.paypal.com/v1/oauth2/token';

   $headers = array(
   		"Accept: application/json",
   		"Accept-Language: en_US"
   	);
   	
   	$postfields = array(
      'grant_type' => 'client_credentials'
    ); 

	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_USERPWD, "$client:$secret");
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postfields));

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_VERBOSE, 1);
	curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);

	$resToken = curl_exec($ch);

	curl_close($ch); 
	
	$printToken = json_decode($resToken, true);

	//echo $resToken;
	//print_r($resToken);
	//echo '<br><br><br>';

 ?>