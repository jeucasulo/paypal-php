<?php

class Session
{

	public static function GetPost($post)
	{

		foreach ($post as $key => $value)
		{
			$_SESSION[$key] = $value;
		}

	}

	public static function GetURL($data, $session)
	{
		if (isset($_SESSION['ACK']) && $_SESSION['ACK'] == 'Success') {				
		// Verifica se o SetEC foi executado com sucesso
	    	
	    	$query = array(
	        	'cmd'    => '_express-checkout',								
	        	// Cria uma query string com cmd = _express-checkout
	       		'token'  => $_SESSION['TOKEN']										
	       		// Adiciona o token = $token
    		);

    		$redirect = sprintf('%s?%s', $data['url'], http_build_query($query));

    		return $redirect;

    	}
	}

	public static function GetQuery($query)
	{
		if (preg_match_all('/(?<name>[^\=]+)\=(?<value>[^&]+)&?/', $query, $matches)) 
		{
	    	foreach ($matches['name'] as $offset => $name) 
	    	{

	        	$_SESSION[$name] = $matches['value'][$offset];

	     	}
    	}
	}

	public static function JustKill($session)
	{
		foreach ($session as $key => $value)
		{
			unset($_SESSION[$key]);
		}
	}

	public static function KillEmAll()
	{
		session_destroy();
		session_unset();
	}
}

?>
