
<?php

include './config.php';

class RunCurl {


  public function Run($reqs, $data){

    $skip = new RunCurl();
    $skip = $skip->SCR($data);
    $reqs += $skip;
    $curl = curl_init();

    curl_setopt($curl, CURLOPT_URL, $data['endpoint']);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($reqs));

    $Call = curl_exec($curl);

    $decodeSNR = urldecode($Call);

    curl_close($curl);

    return $decodeSNR;
    
  } 

    public function SCR($data){

        $credential = array(

        'USER' => $data['user'],
        'PWD' => $data['pwd'],
        'SIGNATURE' => $data['sign'],

        'VERSION' => $data['ver']);

        return $credential;
    }

}


?> 
