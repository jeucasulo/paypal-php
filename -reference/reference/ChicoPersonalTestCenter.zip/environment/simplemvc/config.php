<?php

$localhost = $_SERVER['HTTP_HOST'];

$sandbox = true;
$ver = '200.0';
$endpoint = 'https://api-3t.' . ($sandbox? 'sandbox.': null);
$endpoint .= 'paypal.com/nvp';
$curr = 'BRL';

if($sandbox) {
  $user = 'renan-is-receiving_api1.baybal.co.uk';
  $pwd = 'JJ9K59CVPNNEATW5';
  $sign = 'ASTSMGONs6t5ibcRNYLrqVQAL3rVAeaHP82yHPtSB5wnMq.3t2ky8aOX';

  $url = 'https://www.sandbox.paypal.com/cgi-bin/webscr';

} else {
  $user = '';
  $pwd = '';
  $sign = '';

  $url = 'https://www.paypal.com/cgi-bin/webscr';

};

$arr = array($user, $pwd, $sign, $ver, $url, $endpoint, $localhost, $curr);
$data = compact("user", "pwd", "sign", "ver", "url", "endpoint", "localhost", "curr");



?>
