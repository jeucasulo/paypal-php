# Changes

	Apr 20, 2018

 	index.php updated with a new type of call
 	Add Controllers: DoEC, CreateBA, Refund, RefTrans (as its Routes)
 	Add Views: DoEC
 	Add Classes: SessionRetrieve
 	Added a readonly setting at SetEC's Currency Code
  
  Changed from Error to Cancel
  Set localhost as HTTP_HOST;
