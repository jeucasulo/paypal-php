<?php
ini_set('display_errors', 1);
session_start();

require_once(__DIR__.'/Routes.php');

	function __autoload($class_name)
	{

		$sources = array("./Classes/$class_name.php", "./Controllers/$class_name.php");

		foreach ($sources as $source) {
        if (file_exists($source)) {
            require_once $source;
        }
    }

}

/*

spl_autoload_register (function ($class) {

$sources = array("./Classes/$class.php", "./Controllers/$class.php", "./Views/$class.php ");

    foreach ($sources as $source) {
        if (file_exists($source)) {
            require_once $source;
        }
    }
});

*/

?>
