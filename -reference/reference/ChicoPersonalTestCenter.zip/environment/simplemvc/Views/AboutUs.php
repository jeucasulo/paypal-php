<?php
require_once('./Views/Layout/Layout.php');
?>

<center><h1>AboutUs</h1></center>