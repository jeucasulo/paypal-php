<?php
require_once('./Views/Layout/Layout.php');
?>

<form method="POST" name="form" action="">
<center>
<h2>Are you up to create a new billing agreement?</h2>
<input type="hidden" name="TOKEN" value="<?php echo $_GET['token'];?>">
<button type="submit" class="btn btn-success" name="submit">Yes, I ❤ bills!</button>
<?php

	//if(isset($_POST['submit'])){

	echo '<a href="http://' . $_SERVER['HTTP_HOST'] . '/simplemvc/reftrans" class="btn btn-primary" role="button">Reference Transaction</a>';

  	//}	
  	
  	 //print_r($_SERVER);

?>
</center>
</form>