<?php
	
	require_once('./Views/Layout/Layout.php');

	if(!isset($_SESSION['PAYMENTINFO_0_TRANSACTIONID']) && (isset($_SESSION['TRANSACTIONID']))) 
	{
		$transactionid = $_SESSION['TRANSACTIONID'];

	} elseif (isset($_SESSION['PAYMENTINFO_0_TRANSACTIONID']) && (!isset($_SESSION['TRANSACTIONID']))) {

		$transactionid = $_SESSION['PAYMENTINFO_0_TRANSACTIONID'];

	} else {

		$transactionid = "";
	}

?>

<center>
<form method="POST" name="form" action="">
<center>
<label class="radio-inline">
Do you want to refund the value from transaction no.<input type="text" class="form-control" value="<?php echo $transactionid; ?>" name="transaction_id" required>
<br>

<label class="radio-inline">
<input type="radio" name="reftype" id="full">Full</label>
<label class="radio-inline">
<input type="radio" name="reftype" id="partial">Partial</label>

<br>
<br>
<input type="text" class="form-control" placeholder="How much?" name="rpamount">
<br>
<button type="submit" class="btn btn-primary" name="submit">Refund</button>
</center>
</form>

<script>

		$("input[name=rpamount]").hide();

		$('#partial').on('click', function() {
			$("input[name=rpamount]").show(); 
			$("input[name=rpamount]").addClass('required');
		});

		$('#full').on('click', function() {
			$("input[name=rpamount]").hide();
			$("input[name=rpamount]").removeClass('required');
		});

</script>
</center>