
<link href="https://getbootstrap.com/docs/3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://getbootstrap.com/docs/3.3/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">
<link href="https://getbootstrap.com/docs/3.3/examples/starter-template/starter-template.css" rel="stylesheet">

<script src="https://getbootstrap.com/docs/3.3/assets/js/ie-emulation-modes-warning.js"></script>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">
    <title>Express Checkout - JSv4 & Classic Samples</title>
    <script src="https://www.paypalobjects.com/api/checkout.js"></script>
    
  </head>

  <body>
    <br>
    <nav class="navbar navbar-inverse navbar-fixed-top" >
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="http://<?php echo $_SERVER['HTTP_HOST'] ?>/simplemvc/">Express Checkout</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
           <li><a href="http://<?php echo $_SERVER['HTTP_HOST'] ?>/simplemvc/setec">SetEC</a></li>
            <?php //if(isset($_SESSION['billing'])) { echo '<li><a href="http://echo $_SERVER['HTTP_HOST']/simplemvc/createba">CreateBA</a></li>'; } ?>
            <li><a href="http://<?php echo $_SERVER['HTTP_HOST'] ?>/simplemvc/refund">Refund</a></li>
            <li><a href="http://<?php echo $_SERVER['HTTP_HOST'] ?>/simplemvc/reftrans">RefTrans</a></li>
            <li><a></a></li>
            <li><a></a></li>
            <li><a href="http://<?php echo $_SERVER['HTTP_HOST'] ?>/simplemvc/kill">KILL!</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="https://getbootstrap.com/docs/3.3/assets/js/vendor/jquery.min.js"><\/script>')</script>
<script src="https://getbootstrap.com/docs/3.3/dist/js/bootstrap.min.js"></script>
<script src="https://getbootstrap.com/docs/3.3/assets/js/ie10-viewport-bug-workaround.js"></script>
