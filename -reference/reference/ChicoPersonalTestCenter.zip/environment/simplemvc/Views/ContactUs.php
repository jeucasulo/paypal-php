<?php
require_once('./Views/Layout/Layout.php');
?>

<center><h1>ContactUs</h1></center>