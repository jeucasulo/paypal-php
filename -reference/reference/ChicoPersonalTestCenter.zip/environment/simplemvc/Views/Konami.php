<?php
require_once('./Views/Layout/Layout.php');

if(!isset($_SESSION['PAYMENTINFO_0_TRANSACTIONID'])) {
	$_SESSION['PAYMENTINFO_0_TRANSACTIONID'] = "";
}


?>

<center><h1>How did you get here? (⊙＿⊙')</h1></center>

<br>
<br>
<br>
<br>

<form method="POST" name="form" action="konami">
<center>
<label class="radio-inline">
<input type="checkbox" name="billing"> Do as Billing Agreement?</label>
<br>
<br>
<button type="submit" class="btn btn-primary" name="sub1">HIT ME</button>
<?php
if(isset($_SESSION['redirect'])) {

	$redirect = $_SESSION['redirect'];
	echo '<a role="button" class="btn btn-success" href="'.$redirect.'">Pay</a>';
}
?>
</center>
</form>

<br>
<br>
<br>

<form method="POST" name="form2" action="konami">
<center>
<label class="radio-inline">
Do you want to refund the value from transaction no.<input type="text" class="form-control" value="<?php echo $_SESSION['PAYMENTINFO_0_TRANSACTIONID'] ?>" name="transaction_id" required>
<br>

<label class="radio-inline">
<input type="radio" name="reftype" id="full">Full</label>
<label class="radio-inline">
<input type="radio" name="reftype" id="partial">Partial</label>

<br>
<br>
<input type="text" class="form-control" placeholder="How much?" name="rpamount">
<br>
<button type="submit" class="btn btn-primary" name="sub2">HIT ME</button>
</center>
</form>

<script>

		$("input[name=rpamount]").hide();

		$('#partial').on('click', function() {
			$("input[name=rpamount]").show(); 
			$("input[name=rpamount]").addClass('required');
		});

		$('#full').on('click', function() {
			$("input[name=rpamount]").hide();
			$("input[name=rpamount]").removeClass('required');
		});

</script>