<?php
if(!isset($_REQUEST['jsv4'])) {
require_once('./Views/Layout/Layout.php');
}
?>
<center><h1>ExpressCheckout - Simulating a Payment Setup</h1></center>


</br>
</br>
</br>
</br>

<form method="POST" name="form" id="form" action="">

    <center><div class="panel panel-default" style="width: 600px">
      <div class="panel-heading"> Informações de compra</div>
      <div class="panel-body">

	<div class="form-group">
<div id="address-obligatory">

  <div id="obligatory">
    		    	<!-- ITEMS[0] -->
			<h4>Item Sample 2</h4></br>
		<div class="form-group col-md-6">
	      <label for="inputName0">Name</label>
	      <input type="text" class="form-control" name="NAME0" placeholder="Product Name">
	    </div>
		<div class="form-group col-md-6">
	      <label for="inputDescription0">Description</label>
	      <input type="text" class="form-control" name="DESC0" placeholder="Product Description">
	    </div>
		<div class="form-group col-md-6">
	      <label for="inputQuantity0">Quantity</label>
	      <input type="text" class="form-control" name="QTY0" placeholder="Quantity of Items">
	    </div>
		<div class="form-group col-md-6">
	      <label for="inputItemAmount0">Item Price</label>
	      <input type="text" class="form-control" name="ITEMAMTn0" placeholder="SetPrice"></br>
	    </div>

    		<!-- ITEMS [1] -->
    		<h4>Item Sample 1</h4></br>
    	<div class="form-group col-md-6">
	      <label for="inputName1">Name</label>
	      <input type="text" class="form-control" name="NAME1" placeholder="Product Name">
	    </div>
		<div class="form-group col-md-6">
	      <label for="inputDescription1">Description</label>
	      <input type="text" class="form-control" name="DESC1" placeholder="Product Description">
	    </div>
		<div class="form-group col-md-6">
	      <label for="inputQuantity1">Quantity</label>
	      <input type="text" class="form-control" name="QTY1" placeholder="Quantity of Items">
	    </div>
		<div class="form-group col-md-6">
	      <label for="inputItemAmount1">Item Price</label>
	      <input type="text" class="form-control" name="ITEMAMTn1" placeholder="SetPrice"></br>
	    </div>

      <!-- Total amount -->
			<h4>Total Amount</h4></br>
	    <div class="form-group col-md-6">
	      <label for="inputCartDescription0">Description</label>
	      <input type="text" class="form-control" name="FixedDescription" value="Buy Simulation">
	    </div>
	        <div class="form-group col-md-6">
	      <label for="inputItemsAmount">Price Of Items</label>
	      <input type="text" class="form-control" name="ITEMAMT" value="100" placeholder="99.00">
	    </div>
	      <div class="form-group col-md-6">
	    <label for="inputCurr">Currency</label>
	    <input type="text" class="form-control" name="CURR" placeholder="Brazilian Real R$ - BRL" value="BRL" readonly>
	  </div>
	      <div class="form-group col-md-6">
	    <label for="inputTotalAmount">Total Price Amount</label>
	      <input type="text" class="form-control" name="AMT" placeholder="99.00">
    </br>
        </div>
  </br>
</div>


<div id="addressdiv">
  <h4>Address Information</h4></br>

  <!-- Address -->
  
  <div class="form-group col-md-6">
        <label for="inputStreet1">Street</label>
        <input type="text" class="form-control" name="STREET1" placeholder="Address Street">
    </div>
  <div class="form-group col-md-6">
        <label for="inputStreet2">Street 2</label>
        <input type="text" class="form-control" name="STREET2" placeholder="Address Street 2">
    </div>
  <div class="form-group col-md-6">
        <label for="inputCity">City</label>
        <input type="text" class="form-control" name="CITY" placeholder="CITY">
    </div>
    <div class="form-group col-md-6">
        <label for="inputState">State</label>
        <input type="text" class="form-control" name="STATE" placeholder="State">
    </div>
    <div class="form-group col-md-6">
        <label for="inputZip">ZIP</label>
        <input type="text" class="form-control" name="ZIP" placeholder="ZIP/CEP">
    </div>
  <div class="form-group col-md-6">
        <label for="inputPhone">Phone Number</label>
      <input type="text" class="form-control" name="PHONE" placeholder="Phone Number"></br>
    </div>
</div>


  <label class="radio-inline">
	<input type="checkbox" name="billing" id="billing"> Create a Billing Agreement?</input></label>
  <label class="radio-inline" id="withEC">
  <input type="checkbox" name="withEC" id="withEC"> With Express Checkout?</label>
  <br>
  <label class="radio-inline">
  <input type="checkbox" name="merchantSubject" id="merchantSubject">Include Merchant Email</label>
  <label class="radio-inline">
	<input type="checkbox" name="addressShipping" id="addressShipping">Include Address</label>
	</div>
  </div>
  
</div>
</div>
</div>
<div class="form-group">
<label class="radio-inline">
<input type="radio" name="reftype" id="classic">Classic Checkout</label>
<label class="radio-inline">
<input type="radio" name="reftype" id="rest">Checkout JSv4</label>
  </center>
</br>
<div class="container">
	<div class="row">
  			<center><button type="submit" class="btn btn-primary" name="submit" value="submit">Submit</button>

  <?php

  if(isset($_SESSION['redirect']) && $_SESSION['redirect'] != NULL) {

	  	$redirect = $_SESSION['redirect'];
	  	echo "<script>$('button[name=submit]').hide();</script>";
	  	echo '<a href="'.$redirect.'" class="btn btn-success"">Pay</a></center>';
	  	$_SESSION['redirect'] = "";
  	}

  	else {

  		echo '';

  	}

  ?>
	<div id="paypal-button"></div>

  </div>
</center>
</div>
</form>

<script>
$("#addressdiv").hide();

$('#addressShipping').click(function(){
  if(this.checked){
  $("#addressdiv").show();
} else {
  $("#addressdiv").hide();
}
});

$("#totalamt").hide();

$("#paypal-button").hide();
$("button[name=submit]").hide();

$('#classic').on('click', function() {
  $("#paypal-button").hide();
  $("button[name=submit]").show();
});

$('#rest').on('click', function() {
  $("#paypal-button").show();
  $("button[name=submit]").hide();
});

$('#withEC').hide();

$('#billing').click(function() {
  if (this.checked) {
      $('#withEC').show();
  } else {
      $('#withEC').hide();
      $('input[name=withEC]').attr('checked', false);
  }
});

	$("input[name='ITEMAMTn0']").change(function () {
		$(this).val($(this).val().replace(/,/g, '.'));
	});
		$("input[name='ITEMAMTn1']").change(function () {
		$(this).val($(this).val().replace(/,/g, '.'));
	});

	$("input[name='ITEMAMTn1']").change(function () {
	var amt1 = parseFloat($("input[name='ITEMAMTn0']").val()) * parseFloat($("input[name='QTY0']").val());
	var amt2 = parseFloat($("input[name='ITEMAMTn1']").val()) * parseFloat($("input[name='QTY1']").val());
	var value = parseFloat(amt1) + parseFloat(amt2);
    $("input[name='ITEMAMT']").val(value);
    $("input[name='AMT']").val(value);
 	}).keyup();

 	// jQuery code to transform the serializeArray from
 	// name:name and value:value to name:value
 	// Thanks gabrieleromanato @ https://jsfiddle.net/gabrieleromanato/bynaK/

 	(function ($) {
    $.fn.serializeFormJSON = function () {

        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };
})(jQuery);

</script>



<script>
paypal.Button.render({

  // var data = $("#main :input").serialize();

            env: 'sandbox', // sandbox | production

            // Show the buyer a 'Pay Now' button in the checkout flow
            commit: true,

            // payment() is called when the button is clicked
            payment: function() {

                // Set up a url on your server to create the payment
                var CREATE_URL = "http://<?php echo $_SERVER['HTTP_HOST'] ?>/ppec/nvp-soap/setExpressCheckout.php";

            if($('input#addressShipping').is(':checked')){
                var DATA = $("#address-obligatory :input");
            } else {
                var DATA = $("#obligatory :input");
            }

                // Make a call to your server to set up the payment
                return paypal.request.post(CREATE_URL, DATA.serializeFormJSON())
                    .then(function(res) {
                        return res.TOKEN;
                    });
            },

            // onAuthorize() is called when the buyer approves the payment
            onAuthorize: function(data, actions) {

                // Set up a url on your server to execute the payment
                var EXECUTE_URL = "http://<?php echo $_SERVER['HTTP_HOST'] ?>/ppec/nvp-soap/sucesso.php";

                // Set up the data you need to pass to your server
                var data = {
                    token: data.paymentToken,
                    payerID: data.payerID,
                    FixedDescription: $('input[name=FixedDescription]').val(),
                    AMT: $('input[name=AMT]').val()
                };

                // Make a call to your server to execute the payment
                return paypal.request.post(EXECUTE_URL, data)
                    .then(function (res) {
                        console.log(res),
                        window.location = "./doec?token=" + res.TOKEN
                    });
            }
}, '#paypal-button');

</script>
