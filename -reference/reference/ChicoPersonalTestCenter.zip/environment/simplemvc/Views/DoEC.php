<?php
require_once('./Views/Layout/Layout.php');
?>

<center><h1>ExpressCheckout - Simulating a Payment Confirmation</h1></center>


</br>
</br>
</br>
</br>

<form method="POST" name="form" action="" class="form-group">
    <center><div class="panel panel-default" style="width: 500px; height: 250px;">
      <div class="panel-heading"> Purchase</div>
        <div class="panel-body">

      <label for="confDESC" class="col-xs-2">Summary</label>
      <div class="col-sm-10">
        <input type="text" readonly class="form-control" name="confDESC" value="<?php if(!isset($_SESSION['FixedDescription'])) { echo $_SESSION['FixedDescription']; } else { echo $_SESSION['FixedDescription']; } ?>">
      </div>

      <label for="confCURR" class="col-xs-2">Currency</label>
      <div class="col-sm-10">
        <input type="text" readonly class="form-control" name="confCURR" value="<?php if(!isset($_SESSION['CURR'])) { echo $_SESSION['PAYMENTREQUEST_0_CURRENCYCODE']; } else { echo $_SESSION['CURR']; } ?>">
      </div>

      <label for="confAMT" class="col-xs-2">Total</label>
      <div class="col-sm-10">
        <input type="text" readonly class="form-control" name="confAMT" id="price" value="<?php echo $_SESSION['AMT']; ?>">
      </div>   
  </div>

  <?php if(isset($_REQUEST['PayerID'])) {
    echo '<center><button type="submit" class="btn btn-primary" name="submit">Submit</button></center>';
    echo '<label class="checkbox-inline">';
    echo '<input type="checkbox" name="check" id="checkbox">Change values?</label>';
  } else {
    echo '<h3><span><b>Payment successful executed!</b></span></h3>';
  }
  
  ?></br>
</div>
</center>
</form>

<script>

  $('#checkbox').click(function() {
    if (this.checked) {
        $('#price').attr('readonly', false);
        
    } else {
        $('#price').attr('readonly', true); 
    }
});
  

  //$("input[name='confAMT']").val($("input[name='confIAMT']").val());

  $("input[name='confAMT']").change(function () {
    $(this).val($(this).val().replace(/,/g, '.'));
 //   $("input[name='confAMT']").val($("input[name='confIAMT']").val());
  });

  // $("input[name='confIAMT']").on('keyup', function() {
  //   $("input[name='confAMT']").val($(this).val());
  // });
</script>

