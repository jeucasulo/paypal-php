<?php
require_once('./Views/Layout/Layout.php');

$msg = "Do you really want to hurt me? Do you really want to make me cry?";

?>

<form method="POST" name="form" action="">

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<center><h2><i>"<a href="https://www.youtube.com/watch?v=2nXGPZaTKik" target="_blank" id="message"><?php echo $msg; ?></a>"</i></h2>
<br>
<br>
<button type="submit" class="btn btn-danger" name="submit" value="submit">YES!</button>
<a href="/simplemvc" class="btn btn-primary" role="button" id="restart">Go to Index!</a>
</center>

</form>

<script>$("#restart").hide();</script>

<?php

	if(isset($_POST['submit'])) {

	echo '<script>
	$("#message").text("So long and good night");
	$("#message").attr("href", "https://www.youtube.com/watch?v=UCCyoocDxBA");
	$("button[name=submit]").hide();
	$("#restart").show();
	</script>';

	}
?>