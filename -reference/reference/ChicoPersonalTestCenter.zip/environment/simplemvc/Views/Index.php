<?php
require_once('./Views/Layout/Layout.php');
?>

<center><h1>Express Checkout Experience (NVP & JSv4)</h1></center>
