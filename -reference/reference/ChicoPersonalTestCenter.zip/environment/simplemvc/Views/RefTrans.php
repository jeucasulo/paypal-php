<?php
require_once('./Views/Layout/Layout.php');

if(isset($_SESSION['BILLINGAGREEMENTID'])) {

	$ba_id = $_SESSION['BILLINGAGREEMENTID'];
	
} else {
	
	$ba_id = "";
	
}

?>
<body>
	
<center>
	<form method="POST" name="form" action="">
	<div class="form-inline">
	<h2>What do you want to do with BA no. <input type="text" class="form-control" name="ba_id" value="<?php echo $ba_id?>"> ?</h2></div>
	<br>

		<div class="form-group">
	<label class="radio-inline">
	<input type="radio" name="reftype" id="set">Set Reference Transaction</label>
	<label class="radio-inline">
	<input type="radio" name="reftype" id="cancel">Cancel</label>
	<label class="checkbox-inline">
	<input type="checkbox" name="upinfo" id="upinfo">Update description?</label>
	<br>
	<br>
	<div class="form-inline"><input type="text" class="form-control" name="badesc" placeholder="Place description"></div>
		</div>

		<div class="form-inline">
  	<div class="form-group">
    <label class="sr-only" for="rtamount">Amount</label>
    <input type="text" class="form-control" name="rtamount" placeholder="How much?">
  	</div>  
	<button type="submit" class="btn btn-success" id="button">Set Reference Transaction</button>
		</div>

	</form>
</center>

</body>

<script>

	$("input[name=rtamount]").hide();
	$("#button").hide();
	$("input[name=badesc]").hide();

	$("input[name=rtamount]").change(function () {
		$(this).val($(this).val().replace(/,/g, '.'));
	});

		$("#upinfo").on('click', function() {
			$("input[name=badesc]").toggle().toggleClass('required');
		});	

		$('#set').on('click', function() {
			$("#button").show();
			$("#button").removeClass('btn btn-danger').addClass('btn btn-success');
			$("#button").text('Execute!');
			$("#button").attr('name', 'submit');
			$("input[name=rtamount]").show(); 
			$("input[name=rtamount]").addClass('required');
		});

		$('#cancel').on('click', function() {
			$("#button").show();
			$("#button").removeClass('btn btn-success').addClass('btn btn-danger');
			$("#button").text('Cancel!');
			$("#button").attr('name', 'cancel');
			$("input[name=rtamount]").hide();
			$("input[name=rtamount]").removeClass('required');
		});
</script>