<?php

/* default routes */

Route::set('index', function(){
	Index::CreateView('Index');
});

Route::set('konami', function(){
	Konami::CreateView('Konami');
});

Route::set('cancel', function(){
	Cancel::CreateView('Cancel');
});

/* paypal routes */

Route::set('setec', function(){
	SetEC::CreateView('SetEC');
});

Route::set('doec', function(){
	DoEC::CreateView('DoEC');
});

Route::set('createba', function(){
	CreateBA::CreateView('CreateBA');
});

Route::set('reftrans', function(){
	RefTrans::CreateView('RefTrans');
});

Route::set('refund', function(){
	Refund::CreateView('Refund');
});

Route::set('kill', function(){
	Kill::CreateView('Kill');
});

?>
